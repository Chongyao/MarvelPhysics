#include "points_energy.h"

#include 
typedef zjucad::matrix::matrix<size_t> mati_t;
typedef zjucad::matrix::matrix<double> mati_t;
using namespace std;
using namespace zjucad::matrix;
using namespace bigbang;

namespace marvel{

point_sys::point_sys(const matd_t &points_, const double &rho_){
  
}


}


