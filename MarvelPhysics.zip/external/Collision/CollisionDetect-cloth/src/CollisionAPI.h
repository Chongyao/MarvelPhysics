#ifndef COLLISIONAPI
#define COLLISIONAPI

#include "Collision.h"

#endif