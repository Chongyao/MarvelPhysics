#pragma once

#include "aabb.h"

#define BOX aabb
