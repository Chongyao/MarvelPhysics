#pragma once

// find all sorted roots of a cubic equation
int solveCubic(double c[4], double s[3]);
