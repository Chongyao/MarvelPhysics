#include "config.h"
using namespace std;
using namespace chrono;

namespace marvel{
list<system_clock::time_point> TIMING::starts_;
}
