#ifndef MARVEL_DEFINE_TYPE
#define MARVEL_DEFINE_TYPE
// using REAL = float;
using FLOAT_TYPE = double;
// #define 
#endif
